import React, { Component } from 'react';
import Progbar from '../../Comps/Progbar'
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Snak from '../../Comps/snak';
import Modale from '../../Comps/modal.js'
import Listel from '../../Comps/listel'
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import {FaTimes,FaChevronCircleRight} from  'react-icons/fa'
import Appsbar from '../../Comps/appse'
import Paper from '@material-ui/core/Paper';



function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }

export default class Addemp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            data: [],
            notmess:"",
            notsta:'',
            actext:'',
            wid:72,
            needact:false,
            actfun: null,
            open:false,
            triggerFunc: null
          };
      }





      componentDidMount() {

     this.getdata();


      }


      getdata = ()=>{

        this.setState({
            isLoaded: false,
            open:false,
           
          });
        fetch("http://jom3a.com/akarat/getsoldplots")


        .then(res => res.json())
        .then(
            
          (result) => {
            console.log(JSON.stringify(result))
              this.setState({
                  isLoaded: true,
                  open:true,
                  openmodal:false,
                  notmess:"Loading complete !",
                  notsta:'success',
                  actext:'',
                  needact:true,
                  actfun:this.handleClose,
                  actext:<FaTimes/>,
                 data:result.data
                });
                

              
         
          },
          // Note: it's important to handle errors here
          // instead of a catch() block so that we don't swallow
          // exceptions from actual bugs in components.
          (error) => {
           
           this.setState({
            isLoaded: true,
            open:true,
            notmess:"Something went wrong!",
            notsta:'error',
            actext:'RELOAD',
            actfun:this.getdata,
            needact:true
           
          });

          }
        )
      }


 

handleClose = (event,reason)=>{

    if (reason === 'clickaway') {
        return;
      }

    this.setState({
        open: false,
      
      });

     
};

handleOpen = ()=>{
    this.setState({
        open: true,
      
      });
    };
   

    

handlemClose = (event,reason)=>{

  this.setState({
      openmodal: false,
    
    });

   
};

handlemOpen = ()=>{
  this.setState({
      openmodal: true,
    
    });
  };
 

    
    
    render() {
        return (
          
        <div style={{width:"100%",maxWidth:'100%' }} >
            <div  style={{position:'fixed',width:'100%',top:'0px',zIndex:502}}>
            <Progbar style={{width:'100%'}}  vis={this.state.isLoaded?'none':'block'}/>
            

 </div>
 
 <Appsbar placeh={"Search lot NO. "}/>
 
<Snackbar    anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }} open={this.state.open} autoHideDuration={6000}  onClose={this.handleClose}>
        <Alert  action={
    <Button  style={{display:this.state.needact?"block":"none",display:'flex',alignItems:'center',justifyContent:'center'}} onClick={this.state.actfun} color="inherit" size="small">
     {this.state.actext}
    </Button>
  }   onClose={this.handleClose} severity={this.state.notsta}>
         {this.state.notmess}
        </Alert>
      </Snackbar>

    



<div style={{display:this.state.isLoaded?'block':'none',padding:'15px'}} className={'contentdiv'}>
<div style={{marginTop:"0px"}} >  
<div style={{marginBottom:'10px'}}>
<span style={{color:'grey',fontSize:'20px'}}>{"Recently sold:"}</span>
</div>
<div style={{display:"flex",flexDirection:'row',maxWidth:'100%',width:'100%',justifyContent:"space-between"}}>
{/* {this.state.data.map((ob,index)=>{
  return <Listel lnum={ob.pl_num} ldate={"12-2-2020"} sname={"Wahaj"} />
})}  */}


<Grid container spacing={2}>

        
{this.state.data.map((ob,index)=>{
  return  <Grid onClick={this.handlemOpen}  item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={ob.pl_num} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>
})}
        <Grid  style={{height:'100%'}} item xs={2}>
<Paper elevation={0} style={{width:'100%',display:"flex",
             flexDirection:'column',alignItems:'space-between',height:'100%',
         padding:"10px",backgroundColor:"white",cursor:'pointer',border:'2px solid #68CAE1',color:"#68CAE1",height:'100%'}}>
             <div style={{display:'flex',flexDirection:'row',justifyContent:'center',alignItems:"center",height:'100%'}}>
             <span style={{fontSize:'15px'}}>{"See all "} </span>
             <FaChevronCircleRight style={{marginLeft:"5px"}}/>
             
             </div>
           
             </Paper>
      
</Grid>


      </Grid>



</div>
</div>





<div style={{marginTop:"30px"}} >  
<div style={{marginBottom:'10px'}}>
<span style={{color:'grey',fontSize:'20px'}}>{"Approaching payment:"}</span>
</div>
<div style={{flexGrow:1}}>

<Grid justify={'flex-start'} container spacing={2}>
        {/* <Grid onClick={this.handlemOpen} item xs={2}>
        <Listel urg={'red'}  wdt={"250px"} lnum={"121"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid> */}

{this.state.data.map((ob,index)=>{
  return  <Grid onClick={this.handlemOpen}  item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={ob.pl_num} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>
})}

        {/* <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>
        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>

        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>
        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>
        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>


        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>
        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>
        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>

        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>
        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>
        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>

        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>
        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>
        <Grid item xs={2}>
        <Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
        </Grid>

        <Grid item xs={2}>
        <Listel urg={'green'} wdt={"250px"} lnum={"111"} ldate={"7 days left"} sname={"Wahaj"} />
        </Grid>
       
        <Grid item xs={2}>
        <Listel urg={'green'} wdt={"250px"} lnum={"111"} ldate={"7 days left"} sname={"Wahaj"} />
        </Grid>
        */}

        <Grid item xs={2}>
<Paper elevation={0} style={{justifySelf:"flex-end",width:'100%',display:"flex",
      flexDirection:'column',alignItems:'space-between',height:'100%',
  padding:"10px",backgroundColor:"white",cursor:'pointer',border:'2px solid #68CAE1',color:"#68CAE1"}}>
      <div style={{display:'flex',flexDirection:'row',justifyContent:'center',alignItems:"center",height:'100%'}}>
      <span style={{fontSize:'15px'}}>{"See all "} </span>
      <FaChevronCircleRight style={{marginLeft:"5px"}}/>
      
      </div>
    
      </Paper>
        </Grid>
    
      </Grid>


{/* <Grid container spacing={3} style={{width:'100%'}}> 
{this.state.data.map((ob,index)=>{
  return <Listel lnum={ob.pl_num} ldate={"12-2-2020"} sname={"Wahaj"} />
})} 


<Grid item xs={12}>
<Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
</Grid>


<Grid item xs={12}>
<Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
</Grid>


<Grid item xs={12}>
<Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
</Grid>


<Grid item xs={12}>
<Listel urg={'red'} wdt={"250px"} lnum={"111"} ldate={"2 days left"} sname={"Wahaj"} />
</Grid>
  


<Listel urg={'orange'} wdt={"250px"} lnum={"111"} ldate={"6 days left"} sname={"Wahaj"} />
<Listel urg={'orange'} wdt={"250px"} lnum={"111"} ldate={"6 days left"} sname={"Wahaj"} />
<Listel urg={'lightgreen'} wdt={"250px"} lnum={"111"} ldate={"7 days left"} sname={"Wahaj"} />
<Listel urg={'lightgreen'} wdt={"250px"} lnum={"111"} ldate={"7 days left"} sname={"Wahaj"} />



</Grid> */}
</div>

<Modale modalopen={this.handlemOpen} modalclose={this.handlemClose} open={this.state.openmodal} />


</div>
</div>

            </div>

           
        )

        
    }
        
}




