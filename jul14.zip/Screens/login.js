import React, { Component } from 'react'
import {ReactComponent as ReactLogo1} from '../img/newv.svg';
import {ReactComponent as ReactLogo2} from '../img/newvi.svg';
import Button from '@material-ui/core/Button';
import Comp from '../Comps/comp'
import Ben_input from '../Comps/beninput'
import Grid from '@material-ui/core/Grid';
import Home from './home';
import Emailicon from '@material-ui/icons/EmailOutlined';
import Passicon from '@material-ui/icons/Lock';

export default class Login extends Component {

    constructor(props) {
        super(props);
        this.state = {
         pageid:1,
          };
      }


  

changepageid = (pgid)=>{

  
    this.setState({
        pageid: pgid,
      
      });

console.log(this.state.pageid)
     

     
};


  




    render() {




        switch(this.state.pageid){
             case 1:

               
         return (
            <div style={{width:"100vw",height:'100vh',backgroundColor:'#A9E2F3',display:'flex', alignItems:'center',justifyContent:'center'}} >
             
             <div style={{backgroundColor:'white',width:'60%',height:'70%'}}>            
<Grid style={{height:"100%"}} container spacing={0}>
  <Grid style={{backgroundColor:"#68CAE2",height:"100%",padding:30,display:'flex',flexDirection:"column",alignItems:'space-between',justifyContent:'space-between' }} item  xs={6}>

     <ReactLogo1 height={'40px'} width={'100px'}/>
     <div>   
     <div style={{fontSize:'27px',textAlign:'center',color:"white"}}>
        Don't have an account?
     </div>
   
     <div style={{fontSize:'15px',textAlign:'center',color:"white",marginTop:20,marginBottom:20}}>
        Join for a scalable subscription based ERP softwere with daily cloud backups and 24/7 support. 
     </div>
    

     <div style={{textAlign:'center',marginTop:"15px"}}>
         <Button onClick={()=>{this.changepageid(2)}} disableElevation style={{backgroundColor:"white",color:'#68CAE2',fontWeight:'bold'}} variant="contained" color="primary">
          Create An Account
         </Button>
        
     </div>
     </div>

   <div>
   <Button style={{color:'white'}} color="primary">Request a demo</Button>
   </div>
        </Grid>

      
        <Grid style={{height:"100%",padding:30,display:'flex',flexDirection:"column",alignItems:'space-between',justifyContent:'space-between' }} item  xs={6}>

     <div></div>
<div>
<div style={{fontSize:'20px',textAlign:'left',color:"#68CAE2"}}>
        Welcome back!
        </div>

     <Ben_input id={"email"} label={"Email"} icon={Emailicon} iconex={false} />  
     <Ben_input id={"password"} type={'password'} label={"Password"} icon={Passicon} iconex={false}  />  

     <div>
   <Button onClick={()=>{this.changepageid(6)}} style={{color:'black'}} color="primary">Forgot password?</Button>
   </div>

   <div style={{marginTop:15,textAlign:'right'}}>
       <Button onClick={()=>{this.changepageid(5)}}  style={{backgroundColor:"#68CAE2",color:'white',fontWeight:'bold'}} variant="contained" color="primary">
          Log in
         </Button>

         </div>

 </div>        
        <div>
   </div>
        </Grid>

</Grid>




             </div>
              
            <div >
             
            </div>
            </div>
        )

             break;

             case 2:
      
                return (
                    <div style={{width:"100vw",height:'100vh',backgroundColor:'#A9E2F3',display:'flex', alignItems:'center',justifyContent:'center'}} >
                     
                     <div style={{backgroundColor:'white',width:'30%'}}>   
                      
                     <Grid style={{backgroundColor:"white",height:"100%",padding:10,display:'flex',flexDirection:"column",alignItems:'space-between',justifyContent:'space-between' }} item  xs={12}>
<div>
<ReactLogo2 height={'40px'} width={'100px'}/>
</div>
<div>   

<div style={{textAlign:'center',marginTop:"0px"}}>
<div style={{fontSize:'13x',textAlign:'left',color:"#1c1c1c",fontWeight:'bold'}}>
        Create a company account:
     </div> 
     <div style={{fontSize:'14px',textAlign:'left',color:"#1b1b1b",marginLeft:5,marginTop:0}}>
        Company informations:
    
        <Ben_input id={"cname"} label={"Company name"} icon={null} type={"text"} iconex={false} />  
        <Ben_input id={"name"} label={"Company Email"} icon={null} type={"email"} iconex={false} />  
        <Ben_input id={"cname"} label={"Phone number"} icon={null} type={"number"} iconex={false} />  
        <Ben_input id={"cname"} label={"Fax"} icon={null} type={"text"} iconex={false} />  
        <Ben_input id={"cname"} label={"Country"} icon={null} type={"text"} iconex={false} />  
        <Ben_input id={"cname"} label={"State"} icon={null} type={"text"} iconex={false} /> 
        <Ben_input id={"cname"} label={"City"} icon={null} type={"text"} iconex={false} /> 
        <Ben_input id={"cname"} label={"Street"} icon={null} type={"text"} iconex={false} /> 
        <Ben_input id={"cname"} label={"Building"} icon={null} type={"text"} iconex={false} /> 
        <Ben_input id={"cname"} label={"Tax ID"} icon={null} type={"text"} iconex={false} /> 
       
         
     
     

     </div> 

   

   
</div>
</div>

<div style={{textAlign:"right"}}> 


<Button onClick={()=>{this.changepageid(1)}}  disableElevation style={{ color:'grey',marginRight:10}}   color="primary">
          Back
         </Button>

<Button  onClick={()=>{this.changepageid(3)}} disableElevation style={{ backgroundColor:"#68CAE2", color:'white'}}  color="primary">
          Next
         </Button>
</div>
   </Grid>


                           </div>
                    </div>
                )
             break;


             case 3:
      
                return (
                    <div style={{width:"100vw",height:'100vh',backgroundColor:'#A9E2F3',display:'flex', alignItems:'center',justifyContent:'center'}} >
                     
                     <div style={{backgroundColor:'white',width:'30%',height:'98%'}}>   
                      
                     <Grid style={{backgroundColor:"white",height:"100%",padding:10,display:'flex',flexDirection:"column",alignItems:'space-between',justifyContent:'space-between' }} item  xs={12}>
<div>


<ReactLogo2 height={'40px'} width={'100px'}/>
</div>
<div>   



<div style={{textAlign:'center',marginTop:"0px"}}>
<div style={{fontSize:'13px',textAlign:'left',color:"#1c1c1c",fontWeight:'bold'}}>
        Create a company account:
     </div> 
     <div style={{fontSize:'14px',textAlign:'left',color:"#1b1b1b",marginLeft:5,marginTop:0}}>
        Admin informations:
        <>
        <Ben_input id={"cname"} label={"Name"} icon={null} type={"text"} iconex={false} />  
        <Ben_input id={"112"} label={"Email"} icon={null} type={"email"} iconex={false} />  
        <Ben_input id={"cname"} label={"Number"} icon={null} type={"number"} iconex={false} />  
        <Ben_input id={"cname"} label={"Fax"} icon={null} type={"text"} iconex={false} />  
        <Ben_input id={"cname"} label={"Country"} icon={null} type={"text"} iconex={false} />  
        <Ben_input id={"cname"} label={"State"} icon={null} type={"text"} iconex={false} /> 
        <Ben_input id={"cname"} label={"City"} icon={null} type={"text"} iconex={false} /> 
        <Ben_input id={"cname"} label={"Street"} icon={null} type={"text"} iconex={false} /> 
        <Ben_input id={"cname"} label={"Building"} icon={null} type={"text"} iconex={false} /> 
        <Ben_input id={"cname"} label={"Password"} icon={null} type={"password"}  iconex={false} /> 
        <Ben_input id={"cname"} label={"Confirm password"} icon={null} type={"password"}  iconex={false} /> 
        </>
         
     
     

     </div> 

   

   
</div>


</div>

<div style={{textAlign:"right"}}> 


<Button onClick={()=>{this.changepageid(2)}}  disableElevation style={{ color:'grey',marginRight:10}}   color="primary">
          Back
         </Button>

<Button onClick={()=>{this.changepageid(4)}}  disableElevation style={{ backgroundColor:"#68CAE2", color:'white'}}  color="primary">
          Finish
         </Button>
</div>
   </Grid>


                           </div>
                    </div>
                )
             break;




             case 4:
      
                return (
                    <div style={{width:"100vw",height:'100vh',backgroundColor:'#A9E2F3',display:'flex', alignItems:'center',justifyContent:'center'}} >
                     
                     <div style={{backgroundColor:'white',width:'30%'}}>   
                      
                     <Grid style={{backgroundColor:"white",height:"100%",padding:20,display:'flex',flexDirection:"column",alignItems:'space-between',justifyContent:'space-between' }} item  xs={12}>
<div>


<ReactLogo2 height={'40px'} width={'100px'}/>
</div>
<div>   



<div style={{textAlign:'center',marginTop:"10px"}}>
<div style={{fontSize:'15px',textAlign:'left',color:"#1c1c1c",fontWeight:'bold'}}>
        Account verification:
     </div> 
     <div style={{fontSize:'14px',textAlign:'left',color:"#1b1b1b",marginLeft:5,marginTop:5}}>
        A verification code has been sent to <b>JoeDoe@gmail.com</b>, check the spam folder in case it didn't show up in inbox.
    
        <Ben_input id={"cname"} label={"Code"} icon={null} type={"number"} iconex={false} />  
       
        
         
     
     

     </div> 

   

   
</div>


</div>

<div style={{textAlign:"right",marginTop:20}}> 


<Button  disableElevation style={{ color:'grey',marginRight:10}}   color="primary">
          Resend code
         </Button>

<Button onClick={()=>{this.changepageid(5)}}  disableElevation style={{ backgroundColor:"#68CAE2", color:'white'}}  color="primary">
          Verify
         </Button>
</div>
   </Grid>


                           </div>
                    </div>
                )
             break;


            
             case 6:
      
                return (
                    <div style={{width:"100vw",height:'100vh',backgroundColor:'#A9E2F3',display:'flex', alignItems:'center',justifyContent:'center'}} >
                     
                     <div style={{backgroundColor:'white',width:'30%'}}>   
                      
                     <Grid style={{backgroundColor:"white",height:"100%",padding:20,display:'flex',flexDirection:"column",alignItems:'space-between',justifyContent:'space-between' }} item  xs={12}>
<div>


<ReactLogo2 height={'40px'} width={'100px'}/>
</div>
<div>   



<div style={{textAlign:'center',marginTop:"10px"}}>
<div style={{fontSize:'15px',textAlign:'left',color:"#1c1c1c",fontWeight:'bold'}}>
       Forgot password:
     </div> 
     <div style={{fontSize:'14px',textAlign:'left',color:"#1b1b1b",marginLeft:5,marginTop:5}}>
     Please enter your email
        <Ben_input id={"cname"} label={"Email"} icon={null} type={"email"} iconex={false} />  
       
        
         
     
     

     </div> 

   

   
</div>


</div>

<div style={{textAlign:"right",marginTop:20}}> 


<Button onClick={()=>{this.changepageid(1)}}  disableElevation style={{ color:'grey',marginRight:10}}   color="primary">
          Back
         </Button>

<Button onClick={()=>{this.changepageid(4)}}  disableElevation style={{ backgroundColor:"#68CAE2", color:'white'}}  color="primary">
          Done
         </Button>
</div>
   </Grid>


                           </div>
                    </div>
                )
             break;










             case 5:
      
                return (
               <Home logout={()=>{this.changepageid(1)}}/>
                )
             break;




          


        }

       
     
    }
}
