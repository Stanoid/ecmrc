import React, { Component } from 'react';
import Progbar from '../Comps/Progbar'
import Appbaracc from '../Comps/bars/appbaracc';
import Button from '@material-ui/core/Button';
import Snak from '../Comps/snak';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import {FaTimes} from  'react-icons/fa'
import { PostAdd } from '@material-ui/icons';



function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }

export default class Mainacc extends Component {
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            data: "",
            notmess:"",
            notsta:'',
            actext:'',
            needact:false,
            actfun: null,
            open:false,
            triggerFunc: null
          };
      }





      componentDidMount() {

     this.getdata();


      }


      getdata = ()=>{

        this.setState({
            isLoaded: false,
            open:false,
           
          });
        fetch("http://jom3a.com/akarat/getaccdetails")


        .then(res => res.json())
        .then(
            
          (result) => {
              this.setState({
                  isLoaded: true,
                  open:true,
                  notmess:"Loading complete !",
                  notsta:'success',
                  actext:'',
                  needact:true,
                  actfun:this.handleClose,
                  actext:<FaTimes/>,
                 data:JSON.stringify(result)
                });

              
         
          },
          // Note: it's important to handle errors here
          // instead of a catch() block so that we don't swallow
          // exceptions from actual bugs in components.
          (error) => {
          
           this.setState({
            isLoaded: true,
            open:true,
            notmess:"Somthing went wrong!",
            notsta:'error',
            actext:'RELOAD',
            actfun:this.getdata,
            needact:true
           
          });

          }
        )
      }


 

handleClose = (event,reason)=>{

    if (reason === 'clickaway') {
        return;
      }

    this.setState({
        open: false,
      
      });

     
};

handleOpen = ()=>{
    this.setState({
        open: true,
      
      });
    };
   
    
    render() {
        return (
          
        <div style={{width:'100%'}} >
          <div style={{top:'0px',width:'100%'}}>
          <Appbaracc pagetitle={"Accounting"} />  
        
          
          </div>
 
 

            </div>

           
        )

        
    }
        
}




