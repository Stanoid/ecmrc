import React, { Component } from 'react';
import Progbar from '../Comps/Progbar'
import Button from '@material-ui/core/Button';
import Datagridreport from '../Comps/datagridreport'
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import {FaTimes,FaChevronCircleRight} from  'react-icons/fa'


function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }

export default class Reportg1 extends Component {
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: true,
            data: [],
            notmess:"",
            notsta:'',
            actext:'',
            wid:72,
            needact:false,
            actfun: null,
            open:false,
            triggerFunc: null
          };
      }





      componentDidMount() {

     //this.getdata();


      }


      getdata = ()=>{

        this.setState({
            isLoaded: false,
            open:false,
           
          });
        fetch("http://jom3a.com/akarat/getsoldplots")


        .then(res => res.json())
        .then(
            
          (result) => {
            console.log(JSON.stringify(result))
              this.setState({
                  isLoaded: true,
                  open:true,
                  openmodal:false,
                  notmess:"Loading complete !",
                  notsta:'success',
                  actext:'',
                  needact:true,
                  actfun:this.handleClose,
                  actext:<FaTimes/>,
                 data:result.data
                });
                

              
         
          },
          // Note: it's important to handle errors here
          // instead of a catch() block so that we don't swallow
          // exceptions from actual bugs in components.
          (error) => {
           
           this.setState({
            isLoaded: true,
            open:true,
            notmess:"Something went wrong!",
            notsta:'error',
            actext:'RELOAD',
            actfun:this.getdata,
            needact:true
           
          });

          }
        )
      }


 

handleClose = (event,reason)=>{

    if (reason === 'clickaway') {
        return;
      }

    this.setState({
        open: false,
      
      });

     
};

handleOpen = ()=>{
    this.setState({
        open: true,
      
      });
    };
   

    

handlemClose = (event,reason)=>{

  this.setState({
      openmodal: false,
    
    });

   
};

handlemOpen = ()=>{
  this.setState({
      openmodal: true,
    
    });
  };
 

    
    
    render() {
        return (
          
        <div style={{width:"100%",maxWidth:'100%' }} >
            <div  style={{position:'fixed',width:'100%',top:'0px',zIndex:502}}>
            <Progbar style={{width:'100%'}}  vis={this.state.isLoaded?'none':'block'}/>
            

 </div>
 
<Snackbar    anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }} open={this.state.open} autoHideDuration={6000}  onClose={this.handleClose}>
        <Alert  action={
    <Button  style={{display:this.state.needact?"block":"none",display:'flex',alignItems:'center',justifyContent:'center'}} onClick={this.state.actfun} color="inherit" size="small">
     {this.state.actext}
    </Button>
  }   onClose={this.handleClose} severity={this.state.notsta}>
         {this.state.notmess}
        </Alert>
      </Snackbar>

    



<div style={{display:this.state.isLoaded?'block':'none',paddingTop:'60px'}} className={'contentdiv'}>


<Datagridreport/>



</div>

            </div>

           
        )

        
    }
        
}




