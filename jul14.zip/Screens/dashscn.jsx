import React, { Component } from 'react';
import Progbar from '../Comps/Progbar'
import Appmin from '../Comps/bars/appmin';
import Button from '@material-ui/core/Button';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import {FaTimes} from  'react-icons/fa'



function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }

export default class Dashscn extends Component {
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            data: "",
            notmess:"",
            notsta:'',
            actext:'',
            needact:false,
            actfun: null,
            open:false,
            triggerFunc: null
          };
      }





      componentDidMount() {

     this.getdata();


      }


      getdata = ()=>{

        this.setState({
            isLoaded: false,
            open:false,
           
          });
        fetch("http://jom3a.com/akarat/getaccdetails")


        .then(res => res.json())
        .then(
            
          (result) => {
              this.setState({
                  isLoaded: true,
                  open:true,
                  notmess:"Loading complete !",
                  notsta:'success',
                  actext:'',
                  needact:true,
                  actfun:this.handleClose,
                  actext:<FaTimes/>,
                 data:JSON.stringify(result)
                });

              
         
          },
          // Note: it's important to handle errors here
          // instead of a catch() block so that we don't swallow
          // exceptions from actual bugs in components.
          (error) => {
          
           this.setState({
            isLoaded: true,
            open:true,
            notmess:"Somthing went wrong!",
            notsta:'error',
            actext:'RELOAD',
            actfun:this.getdata,
            needact:true
           
          });

          }
        )
      }


 

handleClose = (event,reason)=>{

    if (reason === 'clickaway') {
        return;
      }

    this.setState({
        open: false,
      
      });

     
};

handleOpen = ()=>{
    this.setState({
        open: true,
      
      });
    };
   
    
    render() {
        return (
          
        <div >
            <div style={{position:'fixed',top:'0px',width:'100%',zIndex:50}}>
            <Progbar  vis={this.state.isLoaded?'none':'block'}/>
            <Appmin pagetitle={"Dashboard"} />            

 </div>
 
 <div  style={{padding:'15px'}}>
<Snackbar    anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }} open={this.state.open} autoHideDuration={6000}  onClose={this.handleClose}>
        <Alert  action={
    <Button  style={{display:this.state.needact?"block":"none",display:'flex',alignItems:'center',justifyContent:'center'}} onClick={this.state.actfun} color="inherit" size="small">
     {this.state.actext}
    </Button>
  }   onClose={this.handleClose} severity={this.state.notsta}>
         {this.state.notmess}
        </Alert>
      </Snackbar>
<div style={{marginTop:"55px",zIndex:-1}}>



<div style={{height:'300px', background:'red'}} >  


</div>

</div>









</div>

            </div>

           
        )

        
    }
        
}




