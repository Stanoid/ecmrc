import { ThemeProvider } from '@material-ui/core'
import React, { Component } from 'react'
import MiniDrawer from '../Comps/drawer'
export default class Home extends Component {
    render() {
        return (
            <div style={{width:"100%"}} >
              
            <div >
                <MiniDrawer logout={this.props.logout} />
            </div>
            </div>
        )
    }
}
