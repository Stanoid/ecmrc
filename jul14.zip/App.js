
import React, { Component } from 'react'
import Menu from './Comps/menu';
import Home from './Screens/home';
import Comp from './Comps/comp';
import Login from './Screens/login'
import Form from './Comps/form';
export class App extends Component {
  constructor(props) {
    super(props);
    this.state = {value: '',pay:0,arr:[],loged:false};

   
  }


  render() {

    switch(this.state.loged){
      case true:
          return <div className="App" style={{display:'flex', flexDirection:'row'}}>
          <Home/>
             </div>
      break;
  
  
      case false:
          return <div className="App" style={{display:'flex', flexDirection:'row'}}>
          <Login/>
             </div>;
      break;
  
  }
  
  }
}

export default App

