import React, { Component } from 'react';
import Progbar from '../Progbar'
import Button from '@material-ui/core/Button';
import Scroll from 'react-scroll';
import SimpleBar from 'simplebar-react';
import 'simplebar/dist/simplebar.min.css';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import Notifel from '../notifel';
import {FaTimes,FaChevronCircleRight,FaUser,FaBell,FaUserCircle,FaRegBuilding,FaEdit,FaChevronCircleDown} from  'react-icons/fa'
import Appsbar from '../appse'
import Paper from '@material-ui/core/Paper';
import Collapsible from 'react-collapsible';
import Userprofile from './userprofile';
import Useredit from './useredit';
import Companyedit from './companyedit';

var Element = Scroll.Element;
var Events = Scroll.Events;
var scroll = Scroll.animateScroll;
var scrollSpy = Scroll.scrollSpy;


function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }

export default class User extends Component {
    constructor(props) {
        super(props);
        this.state = {
         usenave:'def',
          };
      }



 
goto = (navtag)=>{
  this.setState({
      usenave: navtag,
    
    });
  };

    
    
    render() {

    switch(this.state.usenave){
      case 'def':
        return ( <Userprofile closeaux={this.props.closeaux} gotouseredit={this.goto}/> )
      break;

      case 'adminedit':
        return ( <Useredit closeaux={this.props.closeaux} gotouseredit={this.goto} /> )
      break;

      case 'companyedit':
        return ( <Companyedit closeaux={this.props.closeaux}  gotouseredit={this.goto}/> )
      break;
    }

        

        
    }
        
}




