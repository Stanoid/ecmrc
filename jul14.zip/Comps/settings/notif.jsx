import React, { Component } from 'react';
import Progbar from '../Progbar'
import Button from '@material-ui/core/Button';
import Scroll from 'react-scroll';
import SimpleBar from 'simplebar-react';
import 'simplebar/dist/simplebar.min.css';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import Notifel from '../notifel';
import {FaTimes,FaChevronCircleRight,FaUser,FaBell} from  'react-icons/fa'
import Appsbar from '../appse'
import Paper from '@material-ui/core/Paper';



var Element = Scroll.Element;
var Events = Scroll.Events;
var scroll = Scroll.animateScroll;
var scrollSpy = Scroll.scrollSpy;


function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }

export default class Notif extends Component {
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            data: [],
            notmess:"",
            notsta:'',
            actext:'',
            wid:72,
            needact:false,
            actfun: null,
            open:false,
            triggerFunc: null
          };
      }





      componentDidMount() {

     this.getdata();


      }


      getdata = ()=>{

        this.setState({
            isLoaded: false,
            open:false,
           
          });
        fetch("http://jom3a.com/akarat/getsoldplots")


        .then(res => res.json())
        .then(
            
          (result) => {
            console.log(JSON.stringify(result))
              this.setState({
                  isLoaded: true,
                  open:true,
                  openmodal:false,
                  notmess:"Loading complete !",
                  notsta:'success',
                  actext:'',
                  needact:true,
                  actfun:this.handleClose,
                  actext:<FaTimes/>,
                 data:result.data
                });
                

              
         
          },
          // Note: it's important to handle errors here
          // instead of a catch() block so that we don't swallow
          // exceptions from actual bugs in components.
          (error) => {
           
           this.setState({
            isLoaded: true,
            open:true,
            notmess:"Profile not loaded!",
            notsta:'error',
            actext:'RELOAD',
            actfun:this.getdata,
            needact:true
           
          });

          }
        )
      }


 

handleClose = (event,reason)=>{

    if (reason === 'clickaway') {
        return;
      }

    this.setState({
        open: false,
      
      });

     
};

handleOpen = ()=>{
    this.setState({
        open: true,
      
      });
    };
   

    

handlemClose = (event,reason)=>{

  this.setState({
      openmodal: false,
    
    });

   
};

handlemOpen = ()=>{
  this.setState({
      openmodal: true,
    
    });
  };
 

    
    
    render() {
        return (
          
        <div style={{width:"100%",maxWidth:'100%' }} >
            <div  style={{position:'fixed',width:'100%',top:'0px',zIndex:502}}>
            <Progbar style={{width:'100%'}}  vis={this.state.isLoaded?'none':'block'}/>
            

 </div>
 

 <div style={{display:'flex',alignItems:'center',fontSize:15,justifyContent:'space-between',padding:15}}>
   <div style={{display:'flex',alignItems:"center"}}>
<FaBell  style={{ color:'grey', marginRight:"10px",cursor:'pointer'}}/> Notifications
</div>
<FaTimes onClick={this.props.closeaux} style={{fontSize:20, color:'grey', marginRight:"10px",cursor:'pointer'}}/>

</div>

 
<Snackbar    anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }} open={this.state.open} autoHideDuration={6000}  onClose={this.handleClose}>
        <Alert  action={
    <Button  style={{display:this.state.needact?"block":"none",display:'flex',alignItems:'center',justifyContent:'center'}} onClick={this.state.actfun} color="inherit" size="small">
     {this.state.actext}
    </Button>
  }   onClose={this.handleClose} severity={this.state.notsta}>
         {this.state.notmess}
        </Alert>
      </Snackbar>

    


      <div style={{display:this.state.isLoaded?'block':'none'}} className={'contentdiv'}>


      <SimpleBar style={{ maxHeight: "100vh",padding:20,paddingBottom:45,paddingTop:10}}>
        

<Element>
<Notifel/>
</Element>   

<Element>
<Notifel/>
</Element>   

<Element>
<Notifel/>
</Element>   

<Element>
<Notifel/>
</Element>   

<Element>
<Notifel/>
</Element>   

<Element>
<Notifel/>
</Element>   

<Element>
<Notifel/>
</Element>   

<Element>
<Notifel/>
</Element>   

<Element>
<Notifel/>
</Element>   

<Element>
<Notifel/>
</Element>   

<Element>
<Notifel/>
</Element>   

<Element>
<Notifel/>
</Element>  


<Element>
<Notifel/>
</Element>  


<Element>
<Notifel/>
</Element>  



<Element>
<Notifel/>
</Element>  



<Element>
<Notifel/>
</Element>  


<Element>
<Notifel/>
</Element>  

   



        

      </SimpleBar>

</div>




            </div>

           
        )

        
    }
        
}




