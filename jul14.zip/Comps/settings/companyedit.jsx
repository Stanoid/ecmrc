import React, { Component } from 'react';
import Progbar from '../Progbar'
import Button from '@material-ui/core/Button';
import Scroll from 'react-scroll';
import SimpleBar from 'simplebar-react';
import 'simplebar/dist/simplebar.min.css';

import MuiAlert from '@material-ui/lab/Alert';

import {FaTimes,FaChevronCircleLeft,FaCheckCircle,FaTimesCircle} from  'react-icons/fa'
import Ben_input from '../beninput';


export default class Companyedit extends Component {
    constructor(props) {
        super(props);
        this.state = {
         
          };
      }





    


    
    
    render() {
        return (
          
        <div style={{width:"100%",maxWidth:'100%' }} >
         
 

 <div style={{display:'flex',alignItems:'center',fontSize:15,padding:15,justifyContent:'space-between'}}>
   <div style={{display:'flex',alignItems:"center"}}>
<FaChevronCircleLeft onClick={() => { this.props.gotouseredit("def") }}  style={{ color:'grey', marginRight:"10px",cursor:'pointer'}}/> Edit company profile
</div>
<FaTimes onClick={this.props.closeaux} style={{fontSize:20, color:'grey', marginRight:"10px",cursor:'pointer'}}/>

</div>

 
    


      <div style={{marginTop:10}} className={'contentdiv'}>


      <SimpleBar style={{ maxHeight: "100vh",padding:20,paddingBottom:45}}>
        
            
<div>
    
<Ben_input id={"cname"} label={"Company name"} icon={null} type={"text"} iconex={false} />  
        <Ben_input id={"name"} label={"Company Email"} icon={null} type={"email"} iconex={false} />  
        <Ben_input id={"cname"} label={"Phone number"} icon={null} type={"number"} iconex={false} />  
        <Ben_input id={"cname"} label={"Fax"} icon={null} type={"text"} iconex={false} />  
        <Ben_input id={"cname"} label={"Country"} icon={null} type={"text"} iconex={false} />  
        <Ben_input id={"cname"} label={"State"} icon={null} type={"text"} iconex={false} /> 
        <Ben_input id={"cname"} label={"City"} icon={null} type={"text"} iconex={false} /> 
        <Ben_input id={"cname"} label={"Street"} icon={null} type={"text"} iconex={false} /> 
        <Ben_input id={"cname"} label={"Building"} icon={null} type={"text"} iconex={false} /> 
        <Ben_input id={"cname"} label={"Tax ID"} icon={null} type={"text"} iconex={false} /> 
        </div>
   <div style={{textAlign:'right',marginTop:25}}>  
   <Button onClick={() => { this.props.gotouseredit("def") }} style={{color:'grey'}}>Cancel <FaTimesCircle style={{marginLeft:5}} /> </Button>
   <Button style={{color:'#68CAE1'}}>Save <FaCheckCircle style={{marginLeft:5}} /> </Button>
 
   </div>
      
      </SimpleBar>

</div>




            </div>

           
        )

        
    }
        
}




