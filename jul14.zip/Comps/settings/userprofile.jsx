import React, { Component } from 'react';
import Progbar from '../Progbar'
import Button from '@material-ui/core/Button';
import Scroll from 'react-scroll';
import SimpleBar from 'simplebar-react';
import 'simplebar/dist/simplebar.min.css';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import Notifel from '../notifel';
import {FaTimes,FaChevronCircleRight,FaUser,FaBell,FaUserCircle,FaRegBuilding,FaEdit,FaChevronCircleDown} from  'react-icons/fa'
import Appsbar from '../appse'
import Paper from '@material-ui/core/Paper';
import Collapsible from 'react-collapsible';


var Element = Scroll.Element;
var Events = Scroll.Events;
var scroll = Scroll.animateScroll;
var scrollSpy = Scroll.scrollSpy;


function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }

export default class Userprofile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: true,
            data: [],
            notmess:"",
            notsta:'',
            actext:'',
            wid:72,
            needact:false,
            actfun: null,
            open:false,
            triggerFunc: null
          };
      }





      componentDidMount() {

    // this.getdata();


      }


      getdata = ()=>{

        this.setState({
            isLoaded: false,
            open:false,
           
          });
        fetch("http://jom3a.com/akarat/getsoldplots")


        .then(res => res.json())
        .then(
            
          (result) => {
            console.log(JSON.stringify(result))
              this.setState({
                  isLoaded: true,
                  open:true,
                  openmodal:false,
                  notmess:"Loading complete !",
                  notsta:'success',
                  actext:'',
                  needact:true,
                  actfun:this.handleClose,
                  actext:<FaTimes/>,
                 data:result.data
                });
                

              
         
          },
          // Note: it's important to handle errors here
          // instead of a catch() block so that we don't swallow
          // exceptions from actual bugs in components.
          (error) => {
           
           this.setState({
            isLoaded: true,
            open:true,
            notmess:"Profile not loaded!",
            notsta:'error',
            actext:'RELOAD',
            actfun:this.getdata,
            needact:true
           
          });

          }
        )
      }


 

handleClose = (event,reason)=>{

    if (reason === 'clickaway') {
        return;
      }

    this.setState({
        open: false,
      
      });

     
};

handleOpen = ()=>{
    this.setState({
        open: true,
      
      });
    };
   

    

handlemClose = (event,reason)=>{

  this.setState({
      openmodal: false,
    
    });

   
};

handlemOpen = ()=>{
  this.setState({
      openmodal: true,
    
    });
  };
 

    
    
    render() {
        return (
          
        <div style={{width:"100%",maxWidth:'100%' }} >
            <div  style={{position:'fixed',width:'100%',top:'0px',zIndex:502}}>
            <Progbar style={{width:'100%'}}  vis={this.state.isLoaded?'none':'block'}/>
            

 </div>
 

 <div style={{display:'flex',alignItems:'center',fontSize:15,padding:15,justifyContent:'space-between'}}>
   <div style={{display:'flex',alignItems:"center"}}>
<FaUser  style={{ color:'grey', marginRight:"10px",cursor:'pointer'}}/> Profile
</div>
<FaTimes onClick={this.props.closeaux} style={{fontSize:20, color:'grey', marginRight:"10px",cursor:'pointer'}}/>

</div>

 
<Snackbar    anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }} open={this.state.open} autoHideDuration={6000}  onClose={this.handleClose}>
        <Alert  action={
    <Button  style={{display:this.state.needact?"block":"none",display:'flex',alignItems:'center',justifyContent:'center'}} onClick={this.state.actfun} color="inherit" size="small">
     {this.state.actext}
    </Button>
  }   onClose={this.handleClose} severity={this.state.notsta}>
         {this.state.notmess}
        </Alert>
      </Snackbar>

    


      <div style={{display:this.state.isLoaded?'block':'none',marginTop:10}} className={'contentdiv'}>


      <SimpleBar style={{ maxHeight: "100vh",padding:'0px 20px',paddingBottom:45}}>
        
           

<Element>

<div style={{display:'flex',alignItems:'center',justifyContent:'center'}}></div>


<div style={{textAlign:'center'}}>
 <FaUserCircle style={{fontSize:70}} />
</div>

<Paper elevation={2} style={{ marginTop:-30, textAlign:'center',}}>
 <div style={{paddingTop:30,paddingBottom:20}} >
<div style={{fontWeight:"bold",fontSize:17}}>
Jhone Doe
</div>

<div style={{fontSize:12}}>
Accountant at Somthing Co. ltd.
</div>


<div style={{fontSize:12,marginTop:10}}>




<div style={{paddingLeft:20,textAlign:'left',marginTop:10}}>
<div>
  Email:
</div>

<div>
  <b>JhonDoe@gmail.com</b>
</div>

</div>




<div style={{paddingLeft:20,textAlign:'left',marginTop:10}}>
<div>
  Status
</div>

<div style={{color:'green',fontWeight:'bold'}} >
  Active
</div>

</div>




</div>


<Collapsible easing={'ease-in'} transitionTime={200} trigger={<div style={{margin:10,textAlign:'left'}}>
<Button style={{color:'#68CAE1'}}>More info <FaChevronCircleDown style={{marginLeft:5}} /> </Button>
</div>}>
    

<div style={{paddingLeft:20,textAlign:'left',marginTop:10}}>
<div>
  Phone
</div>

<div style={{color:'green',fontWeight:'bold'}} >
  Active
</div>

</div>



<div style={{paddingLeft:20,textAlign:'left',marginTop:10}}>
<div>
  Email
</div>

<div style={{color:'green',fontWeight:'bold'}} >
  Active
</div>

</div>


    </Collapsible>


    <div style={{display:'flex',justifyContent:"flex-end",paddingRight:10}}>
<Button  onClick={() => { this.props.gotouseredit("adminedit") }} style={{color:'#FC7A1E'}}>Edit <FaEdit style={{marginLeft:5}} /> </Button>
</div> 
  
 </div>

</Paper>


<Paper elevation={1} style={{ marginTop:10,marginBottom:15, textAlign:'center',}}>


 <div style={{paddingTop:10,paddingBottom:10}} >

<div style={{display:'flex',alignItems:"center",justifyContent:'center'}}>


<div>
<div style={{fontWeight:"bold",fontSize:17}}>
Something Co.ltd.
</div>

<div style={{fontSize:12}}>
Somethingcoltd@gmail.com
</div>

</div>
</div>



<div style={{fontSize:12,marginTop:10}}>

<div style={{paddingLeft:20,textAlign:'left'}}>
<div>
  Subscription date:
</div>

<div >
 <b>12/2/2021</b>
</div>

</div>



<div style={{paddingLeft:20,textAlign:'left',marginTop:10}}>
<div>
  Ends on:
</div>

<div>
<b>12/2/2023</b>
</div>

</div>





<div style={{paddingLeft:20,textAlign:'left',marginTop:10}}>
<div>
  Status
</div>

<div style={{color:'green',fontWeight:'bold'}} >
  Active
</div>

</div>


<Collapsible easing={'ease-in'} transitionTime={200} trigger={<div style={{margin:10,textAlign:'left'}}>
<Button style={{color:'#68CAE1'}}>More info <FaChevronCircleDown style={{marginLeft:5}} /> </Button>
</div>}>
    

<div style={{paddingLeft:20,textAlign:'left',marginTop:10}}>
<div>
  Phone
</div>

<div style={{color:'green',fontWeight:'bold'}} >
  Active
</div>

</div>



<div style={{paddingLeft:20,textAlign:'left',marginTop:10}}>
<div>
  Email
</div>

<div style={{color:'green',fontWeight:'bold'}} >
  Active
</div>

</div>


    </Collapsible>

</div>

<div style={{display:'flex',justifyContent:"flex-end",paddingRight:10}}>
<Button onClick={() => { this.props.gotouseredit("companyedit") }} style={{color:'#FC7A1E'}}>Edit <FaEdit style={{marginLeft:5}} /> </Button>
</div> 
 
 </div>

</Paper>

</Element>   
   
   



        

      </SimpleBar>

</div>




            </div>

           
        )

        
    }
        
}




