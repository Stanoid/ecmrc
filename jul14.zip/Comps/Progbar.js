import React, { useState } from 'react';
import Papero from '@material-ui/core/LinearProgress'
import { makeStyles, useTheme } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';






const useStyles = makeStyles((theme) => ({
    colorPrimary: {
    backgroundColor: '#353535',
  },

  barColorPrimary: {
    backgroundColor: '#68CAE1',
  }
}));

export default function Progbar(props) {
  const classes = useStyles();
  const theme = useTheme();
  
  

  
  return (
   <div>
    <Papero style={{height:'2px',zIndex:-100,opacity:props.vis=="block"?1:0}}  classes={{
    colorPrimary: classes.colorPrimary, // class name, e.g. `classes-nesting-root-x`
    barColorPrimary: classes.barColorPrimary, // class name, e.g. `classes-nesting-label-x`
  }} />
    </div>
  );
}