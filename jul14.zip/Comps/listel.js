import React from 'react'
import Button from '@material-ui/core/Button';
import Paper from '@material-ui/core/Paper';
import { useSpring, animated } from 'react-spring'
import Grid from '@material-ui/core/Grid';
import { makeStyles, useTheme } from '@material-ui/core/styles';


const useStyles = makeStyles((theme) => ({
  root: {
    textAlign:'left'
  }
}));




function Listel(props) {
  const propsa = useSpring({ to: { opacity: 1 }, from: { opacity: 0 }})
  const classes = useStyles();
  const theme = useTheme();

  return (
    <animated.div style={propsa}>
     <Button  classes={{      
      root: classes.root,
    }} style={{padding:0,width:"100%",height:'100%', textTransform: 'none'}}>

     
      <Paper  elevation={1} style={{width:"100%",height:'100%',
  padding:"10px",backgroundColor:"white",cursor:'pointer'}}>

<Grid  container spacing={0}>
<Grid justify={"flex-start"} style={{width:'100%',height:'100%'}} item xs={12}>
        <div style={{width:'100%',height:'100%'}}> { "Lot NO. "+ props.lnum } </div>
        </Grid>

        
<Grid style={{width:'100%',height:'100%',textTransform: 'none'}} item xs={6}>
<div style={{width:'100%',height:'100%'}}> <span style={{fontSize:'13px'}}>{props.sname}</span></div>
        </Grid>



     
        <Grid style={{width:'100%',height:'100%',textTransform: 'none',textAlign:'right'}} item xs={6}>
<div style={{width:'100%',height:'100%'}}> <span style={{fontSize:'13px', color:props.urg}}>  {props.ldate}</span></div>
        </Grid>

        </Grid>
      {/* { "Lot NO. "+ props.lnum }
      <div style={{display:'flex',flexDirection:'row',justifyContent:'space-between'}}>
      <span style={{fontSize:'13px'}}>{props.sname}</span>
      <span style={{fontSize:'13px', color:props.urg}}>  {props.ldate}</span>
      </div> */}
    
      </Paper>
      </Button>
      </animated.div>
 
  )
}

export default Listel
