import React from 'react';
import Homesrn from '../Screens/homescn';
import Mainwer from '../Screens/mainwer';
import Mainpur from '../Screens/mainpur';
import Mainsale from '../Screens/mainsale';
import Mainacc from '../Screens/mainacc';
import Mainemp from '../Screens/mainemp';
import Reports from '../Screens/reportsscn';



function Nav(props) {
    const navtag = props.navtag;
 
switch(navtag){


    case 'hom':
        return <Homesrn logout={props.logout} />;
    break;


    case 'sale':
        return <Mainsale/>;
    break;


    case 'pur':
        return <Mainpur  />;
    break;

    case 'acc':
        return <Mainacc/>;
    break;

    case 'wer':
        return <Mainwer/>;
    break;

    case 'emp':
        return <Mainemp/>;
    break;

    case 'rep':
        return <Reports/>;
    break;

}

 
}

export default Nav