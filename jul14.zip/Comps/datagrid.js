import React, { useState } from 'react';
import { DataGrid, GridToolbar } from '@material-ui/data-grid';
//import GridLocaleText from './datagridtrans.ts';
import Button from '@material-ui/core/Button';
import CircularProgress from '@material-ui/core/CircularProgress';
import CircularProgressWithLabel from './cirprog'



const columns = [
  { field: 'id', headerName: 'No',  flex: 0.16,hide:'true' },
  
  { field: 'amount',
  
  valueFormatter: (params) => params.value+" SDG",
  headerName: 'Amount', flex: 0.16 },
  { field: 'method', headerName: 'Method', flex: 0.16 ,type:'component'},
  {
    field: 'from',
    headerName: 'From',
  
    flex: 0.16,
  },

  {
    field: 'to',
    headerName: 'To',
  

    flex: 0.16,
  },
  
  {
    field: 'type',
    headerName: 'Done',
    flex:0.08,
    renderCell: (params) => (
    
        
      <CircularProgressWithLabel thickness={4} size={30}  prog={params.value} />

     
    ),
  },


  {
    field: 'act',
    headerName: 'Actions',
    flex:0.08,
    renderCell: (params) => (
      <strong>
        
        <Button
          variant="contained"
          color= {params.value?"primary":'secondary'} 
          size="small"
          onClick={()=>{
            alert(params.row.id)
          }}
          
        >
         {params.value?"Pay":'Paid'}
        </Button>
      </strong>
    ),
  },

];

const rows = [
  { id: 1, amount: 212, method: 'Check', from: '11212',to:'55354',type:12, act:1 },
  { id: 2, amount: 212, method: 'Cash', from: '11212',to:'55354',type:43 ,act:0},
  

];

export default function DataGridDemo() {

    const [select, setSelection] = React.useState([]);


    const alsele= () =>{


       alert(select);
      };

  return (
    <div style={{ height:'100%', width: '100%' }}>

       
      <DataGrid 
      
     
   

      localeText={{
    toolbarDensity: 'Size',
    toolbarDensityLabel: 'Size',
    toolbarDensityCompact: 'Small',
    toolbarDensityStandard: 'Medium',
    toolbarDensityComfortable: 'Large',
  }}

  components={{
    Toolbar: GridToolbar,
  }}
  
  disableSelectionOnClick={true}
  hideFooterPagination={true}
      loading={false}  hideFooter={false} rows={rows} columns={columns}  pageSize={rows.length} checkboxSelection={false} 
      
      onSelectionModelChange={(newSelection) => {
       console.log(newSelection);
    }}

    
    onRowSelected={(newSelection) => {
       // console.log(newSelection);
     }}
    onRowSelected={(newSelection) => {
        console.log(newSelection);
     }}
    
     />
   
    </div>
  );
}


