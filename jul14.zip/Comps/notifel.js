import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';


const useStyles = makeStyles((theme) => ({
  margin: {
    margin: theme.spacing(0),
  },
}));

export default function Notifel (props) {
  const classes = useStyles();

  return (

    <Button style={{padding:0,width:"100%",height:'100%', textTransform: 'none',textAlign:'left',borderRadius:0}}>
    <div style={{padding:'5px 10px',marginTop:5,display:'flex',alignContent:"center",justifyContent:'space-between',width:'100%',borderBottom:'1px solid lightgrey'}}>
<div>
    <div>
    A <b>Selling</b> request has been received from <b>Sales</b> 
    </div>

    <div style={{color:'gray'}}>
    4h ago
    </div>

</div>   

<div style={{display:'flex', justifyContent:'flex-end', alignItems:'center',marginLeft:"10px"}}> 
           <div style={{width:10,height:10, backgroundColor:"#FC7A1E", borderRadius:'100px'}}>
         
           </div>
         </div>


    </div>

    </Button>
  );
}