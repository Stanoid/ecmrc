import React from 'react';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';

 
class Meneln extends React.Component {
 
 
  render() {
  
    return (
     <div>
 <ListItem style={{backgroundColor:this.props.sele?'#FC7A1E':''}} button key={this.props.title}>
              <ListItemIcon style={{color:'white'}}>{<this.props.icon style={{fontSize:'20px'}} />}</ListItemIcon>
              <ListItemText style={{color:this.props.sele?'white':'#BDBDBD',fontWeight:'bold'}} primary={this.props.title} />
            </ListItem>
     </div>

    );
  }
}
 

export default Meneln