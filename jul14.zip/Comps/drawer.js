import React, { useState } from 'react';
import clsx from 'clsx';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import CssBaseline from '@material-ui/core/CssBaseline';
import IconButton from '@material-ui/core/IconButton';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ListItem from '@material-ui/core/ListItem';
import Menel from './meneln';
import Setnav from './setnav';
import Content from './content';
import Paper from '@material-ui/core/Paper';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import { useSpring, animated } from 'react-spring'
import {ReactComponent as ReactLogo1} from '../img/news.svg';
import {FaHome,FaUserCircle,FaEllipsisV,FaCog,FaChartLine,FaDollarSign,FaBars,FaBell,FaHeadset,FaArrowAltCircleUp,FaPowerOff,FaWarehouse,FaUsers,FaBoxes } from  'react-icons/fa';

const drawerWidth = 240;


const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    width:'100%'
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  paper:{
backgroundColor:"red"
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  menuButton: {
    marginRight: 36,
  },
  hide: {
    display: 'none',
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    overflowY:'hidden',
    whiteSpace: 'nowrap',
  },
  drawerOpen: {
    width: drawerWidth,
    overflowX:'hidden',
    zIndex:1000,
    overflowY:'hidden',
    backgroundColor:'#353535',
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
     
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  draweraux: {
    marginLeft: drawerWidth,
  
    overflowY:'hidden',
    whiteSpace: 'nowrap',
  },
  drawerClose: {
    zIndex:1000,
    backgroundColor:'#353535',
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    overflowY: 'hidden',
    width: theme.spacing(7) + 1,
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9) + 1,
    },
  },
  drawerOpenaux: {
    marginLeft: drawerWidth,
    overflowX:'hidden',
    zIndex:1000,
    overflowY:'hidden',
    backgroundColor:'#353535',
    transition: theme.transitions.create('margin-left', {
      easing: theme.transitions.easing.sharp,
     
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerCloseaux: {
    zIndex:1000,
    backgroundColor:'#353535',
    transition: theme.transitions.create('margin-left', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    overflowY: 'hidden',
    marginLeft: theme.spacing(7) + 1,
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(9) + 1,
    },
  },
  



  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
   
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
   width:'100%',
    marginLeft: theme.spacing(7) + 1,
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(9) + 1,},
  },
}));

export default function MiniDrawer(props) {
  const classes = useStyles();
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  const [closeaux, setaux] = React.useState(true);
  const [navtago, setnavtag] = React.useState('hom');
  const [navset, setnavset] = React.useState('def');
  
  const propsan = useSpring({ to: { marginLeft: 0 }, from: { marginLeft: -1000 } })
  
  
  const handleDrawerOpen = () => {
    if(open==false){
      setOpen(true);
    }else{
      setOpen(false);
    }
  };


  const handlenavtag= (navt) =>{
   
  
    setnavtag(navt);
setOpen(false);
setaux(true);
  // alert(navt);
  };



  const handleDrawerOpen1 = () => {
 
      setOpen(true);
    
     
    
  };


  const handleDrawerClose = () => {

      setOpen(false);
      
      
   
    
  };

  const handleaux = () => {

setaux(true);
setnavset("def");    
    
 
  
};

const handleauxa = (setnav) => {

  setaux(false);
  handleDrawerClose();
  setnavset(setnav);      
      
   
    
  };

  return (
    <div style={{width:"100%"}} className={classes.root}>
      <CssBaseline />
      
      <Drawer
         onMouseOver={handleDrawerOpen1}
         onMouseLeave={handleDrawerClose}
        variant="permanent"
        className={clsx(classes.drawer, {
          [classes.drawerOpen]: open,
          [classes.drawerClose]: !open,
        })}
        style={{position:"fixed"}}
        classes={{
          paper: clsx({
            [classes.drawerOpen]: open,
            [classes.drawerClose]: !open,
          }),
        }}
      >
        <div style={{height:'50px' ,display:'flex',alignItems:'center',justifyContent:'center'}}>
        <ListItemIcon style={{color:'white',
        display:'flex',alignItems:"center",justifyContent:"center"}}>
          {
         <ReactLogo1 style={{marginLeft:'-10px'}} height={'40px'} width={'40px'}/>}
         </ListItemIcon>      
          <IconButton style={{marginRight:'-10px',display:'none'}} onClick={handleDrawerOpen}>
            {open? <ChevronLeftIcon style={{color:'white'}} /> : <ChevronRightIcon  style={{color:'white'}} />}
          </IconButton>



        </div>

      
        
       

        <List>
         
           
        <div  onClick={() => { handlenavtag("hom") }}>
            <Menel sele={navtago=='hom'?1:0} title={"Home"} icon={FaHome} />
            </div>
        
            <div  onClick={() => { handlenavtag("pur") }}>
            <Menel sele={navtago=='pur'?1:0} title={"Purchases"} icon={FaBoxes} />
            </div>

            <div  onClick={() => { handlenavtag("sale") }}>
            <Menel sele={navtago=='sale'?1:0} title={"Sales"} icon={FaDollarSign} />
            </div>
            <div  onClick={() => { handlenavtag("acc") }}>
            <Menel sele={navtago=='acc'?1:0} title={"Accounting"} icon={FaChartLine} />
            </div>

            <div  onClick={() => { handlenavtag("wer") }}>
            <Menel sele={navtago=='wer'?1:0} title={"Warehouse"} icon={FaWarehouse} />
            </div>
            <div  onClick={() => { handlenavtag("emp") }}>
            <Menel sele={navtago=='emp'?1:0} title={"Employees"} icon={FaUsers} />
            </div>

            <div  onClick={() => { handlenavtag("rep") }}>
            <Menel sele={navtago=='rep'?1:0} title={"Reports"} icon={FaBars} />
            </div>
         
         
        </List>

       <div style={{padding:'10px'}}>
         <div style={{width:'100%',borderBottom:'1px solid grey', 
         alignSelf:'center'}}> </div>
           </div>
    
        <List>
         
        <div onClick={() => { handleauxa("not") }} style={{display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'flex-start'}}>

         <ListItem button key={'Notifications'}>
           <ListItemIcon style={{color:'white'}}>{<><FaBell style={{fontSize:'20px'}}
           
           />
           <div style={{display:'flex', justifyContent:'flex-end', alignItems:'center',marginLeft:"10px"}}> 
           <div style={{width:8,height:8, backgroundColor:"#FC7A1E", borderRadius:'100px'}}>
         
           </div>
         </div>
         </>
           }</ListItemIcon>
           <ListItemText style={{color:'#BDBDBD'}} primary={'Notifications'} />
          
         </ListItem>
    
        </div>
         
         </List>
       
         <div style={{padding:'10px'}}>
         <div style={{width:'100%',borderBottom:'1px solid grey', 
         alignSelf:'center'}}> </div>
           </div>
         <List>
           <div onClick={() => { handleauxa("sup") }}>
           <Menel   title={"Support"} icon={FaHeadset} />
           </div>
        

    <div style={{display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'flex-start'}}>
       
         <ListItem  key={'Jhone doe'}>
           <ListItemIcon style={{color:'white'}}>{<FaUserCircle style={{fontSize:'20px'}} />}</ListItemIcon>
          
           <ListItemText style={{color:'#BDBDBD'}} primary={'Jhone doe'} />
           <FaPowerOff onClick={props.logout} style={{ color:'white', marginRight:"10px",cursor:'pointer'}}/>
           <FaCog onClick={() => { handleauxa("set") }} style={{ color:'white', marginRight:"10px",cursor:'pointer'}}/>
            <FaEllipsisV onClick={() => { handleauxa("user") }} style={{ color:'white', cursor:'pointer'}} />
         </ListItem>
    
        </div>
      
     </List>

  
   


      </Drawer>


    
        
    
         <Paper elevation={3} square 
  
  style={{position:"fixed",width:'30%',padding:0,backgroundColor:'white',height:'100%',display:closeaux?"none":"block"}}
  className={clsx(classes.draweraux, {
   [classes.drawerOpenaux]: open,
   [classes.drawerCloseaux]: !open,
  
 })}

 classes={{
   paper: clsx({
     [classes.drawerOpenaux]: open,
     [classes.drawerCloseaux]: !open,
    
   }),
 }}

  
  >
<div 


>

  
<Setnav closeaux={handleaux} navtag={navset} />


</div>
  </Paper>
    
  
     
      <main  onClick={handleDrawerClose} className={classes.content}>
     
      <Content clsaux={handleaux} logout={props.logout}  style={{width:"100%"}} navtag={navtago} />
    
      </main>
    </div>
    
  );
}