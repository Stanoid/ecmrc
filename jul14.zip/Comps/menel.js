import Radium from 'radium';
import React from 'react';

 
class Menel extends React.Component {
 
 
  render() {
    // Radium extends the style attribute to accept an array. It will merge
    // the styles in order. We use this feature here to apply the primary
    // or warning styles depending on the value of the `kind` prop. Since its
    // all just JavaScript, you can use whatever logic you want to decide which
    // styles are applied (props, state, context, etc).
    return (
        <div style={styles.base}>
             <div style={{display:'flex',flexDirection:'row'}}>
             <div style={{marginRight:'16px', fontSize:'20px',color:'white'}}>
           <this.props.icon/>
           </div>
           <div>{this.props.title}</div>
             </div>

             <div style={{display:'flex', justifyContent:'flex-end', alignItems:'center'}}> 
               <div style={{width:8,height:8, backgroundColor:"lightblue", borderRadius:'100px', display:this.props.vis}}>
             
               </div>
             </div>
            
       </div>
    );
  }
}
 
Menel = Radium(Menel);
 

// You can create your style objects dynamically or share them for
// every instance of the component.
var styles = {
  base: {
    height:'25px',borderRadius:10,
       padding:'7px 7px',
         fontSize:'14px',display:'flex',flexDirection:'row',alignItems:'center',
         fontWeight:'bold',color:'#BDBDBD',letterSpacing:'0.6px',cursor:'pointer',justifyContent:'space-between',
         
 
    // Adding interactive state couldn't be easier! Add a special key to your
    // style object (:hover, :focus, :active, or @media) with the additional rules.
    ':hover': {
        height:'25px',borderRadius:10,
        padding:'7px 7px',backgroundColor:'#424242',
         fontSize:'14px',display:'flex',flexDirection:'row',alignItems:'center',
         fontWeight:'bold',color:'white',letterSpacing:'0.6px',cursor:'pointer',justifyContent:'space-between',
         
 
    }
  },

  
 
  primary: {
    background: '#0074D9'
  },
 
  warning: {
    background: '#FF4136'
  }
};

export default Menel