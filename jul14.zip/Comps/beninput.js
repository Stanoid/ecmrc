import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import InputAdornment from '@material-ui/core/InputAdornment';
import FormControl from '@material-ui/core/FormControl';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';


const useStyles = makeStyles((theme) => ({
  margin: {
    margin: theme.spacing(0),
  },
}));

export default function Ben_input(props) {
  const classes = useStyles();

  return (
    <div>
      <FormControl >
        <InputLabel htmlFor="input-with-icon-adornment">{props.label}</InputLabel>
        <Input
        fullWidth={true}
        type={props.type}
          id={props.id}
          startAdornment={
            props.iconex?   <InputAdornment position="start">
            <props.icon style={{color:"#68CAE2"}} />
            </InputAdornment>: false
         
          }
        />
      </FormControl>
     
    
    </div>
  );
}