import React, { Component } from 'react'


class Form extends React.Component {
    constructor(props) {
      super(props);
      this.state = {valfue: ''};
  
    }
  
   
  
  
    render() {
      return (
        <form onSubmit={this.props.handleSubmit}>
          <label>
            Name:
            <input type="text" value={this.props.value} onChange={this.props.handleChange} />
          </label>

          <label>
            Payment:
            <input type="number" value={this.props.pay} onChange={this.props.handleChangeo} />
          </label>
          <input type="submit" value="Submit" />
        </form>
      );
    }
  }

export default Form
