import React, { Component } from 'react';
import Menel from './menel';

import {ReactComponent as ReactLogo} from '../img/newv.svg';
import {FaHome,FaUserCircle,FaEllipsisV,FaCog,FaChartLine,
    FaMapMarked,FaDollarSign,FaBars,FaArrowAltCircleLeft,FaHeadset,FaArrowAltCircleUp} from  'react-icons/fa'



export default class menu extends Component {
    constructor(props) {
        super(props);
        this.state = {date: new Date()};
      }
    
    render() {
        return (
           
            <div  style={{width:'12%',height:'100%',backgroundColor:'#353535',
            paddingLeft:'12px',paddingRight:'12px',paddingBottom:'12px',
            position:'fixed',top:'0px',display:'flex',flexDirection:"column",alignItems:'flex-start'
            ,justifyContent:"space-between",
            }} >


                <div style={{padding:"20px 0px", fontSize:"20px",color:'white'}}>
            <ReactLogo height={'100px'} width={'120px'}/>
             
                </div>
                

               
                <div>
                 
              <Menel vis={"none"} title={"Home"} icon={FaHome} />
             
              <Menel vis={"none"} title={"Dashboard"} icon={FaChartLine} />
              <Menel vis={"none"} title={"Lot operations"} icon={FaMapMarked} />
              <Menel vis={"none"} title={"Payments"} icon={FaDollarSign} />
              
              <Menel vis={"none"} title={"Reports"} icon={FaBars} />

              <div style={{width:'100%',borderBottom:'1px solid grey', alignSelf:'center',marginTop:'15px',marginBottom:'15px'}}> </div>
           
             
              <Menel vis={"Block"} title={"Requests"} icon={FaArrowAltCircleLeft} />
              <Menel vis={"none"} title={"Payments"} icon={FaHome} />

              <div style={{width:'100%',borderBottom:'1px solid grey', alignSelf:'center',marginTop:'15px',marginBottom:'15px'}}> </div>
           
              <Menel vis={"none"} title={"Support"} icon={FaHeadset} />
              
              <Menel vis={"block"} title={"Upgrade"} icon={FaArrowAltCircleUp} />
              
    </div>




              <div style={{width:'100%'}}>
                  
              <div style={{width:'100%',borderBottom:'1px solid grey', alignSelf:'center',marginBottom:'5px'}}> </div>
           
             <div style={{display:'flex',flexDirection:'row',color:'white'
             ,justifyContent:"space-between",alignItems:'center',width:'100%',padding:'20px 0px'}}>
                 
                 <div >
             <div style={{fontSize:'25px',display:'flex',flexDirection:'row',alignItems:"center"}}>
            <FaUserCircle/>
            <div style={{fontSize:'15px',marginLeft:'5px',fontWeight:"bold"}}>
            {"Jhon doe"}
            </div>
             </div>
             </div>

             <div style={{display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
             <FaCog style={{marginRight:"10px",cursor:'pointer'}}/>
            <FaEllipsisV style={{cursor:'pointer'}} />
            
             </div>

           


            

             
            </div>
            </div>
          

            </div>
        )

        
    }
        
}




