import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Button from '@material-ui/core/Button';

import Backdrop from '@material-ui/core/Backdrop';
import Grid from '@material-ui/core/Grid';
import Fade from '@material-ui/core/Fade';
import Datagrid from './datagrid'
const useStyles = makeStyles((theme) => ({
  modal: {
    display: 'flex',
    alignItems: 'center',
    
   paddingLeft: theme.spacing(9),
    justifyContent: 'center',
  },
  paper: {
    backgroundColor:"white",
   borderRadius:'5px',
   width:'90vw',
   height:'95vh',
    padding:'15px',
    display:'flex',
    flexDirection:'column',
   justifyContent:"space-between"

  },
}));

export default function Modale(props) {
  const classes = useStyles();
  
  return (
    <div>
    
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        className={classes.modal}
        open={props.open}
        onEscapeKeyDown={props.modalclose}
        onClose={props.modalclose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 100,
        }}
      >
        <Fade in={props.open}>
          <div  className={classes.paper}>
         <div>
           
<Grid  container spacing={0}>
<Grid justify={"flex-start"} style={{width:'100%',height:'100%'}} item xs={8}>
        <div style={{width:'100%',height:'100%',fontSize:"20px"}}> {'Lot NO. 1221 payments:'} </div>
        </Grid>

        <Grid justify={"flex-start"} style={{width:'100%',height:'100%'}} item xs={4}>
        <div style={{width:'100%',height:'100%', display:"flex",flexDirection:'row',justifyContent:"space-between"}}>
          <div>{""}</div>
          <div>{""}</div>
          <div>{""}</div>
          
           </div>
        </Grid>


        <Grid justify={"flex-start"} style={{width:'100%',height:'100%'}} item xs={8}>
        <div style={{width:'100%',height:'100%',fontSize:"18"}}> {'Wahaj plot'} </div>
        </Grid>
        <Grid justify={"flex-start"} style={{width:'100%',height:'100%'}} item xs={4}>
        <div style={{width:'100%',height:'100%', display:"flex",flexDirection:'row',justifyContent:"space-between"}}>
        
          
           </div>
        </Grid>
        </Grid>
         </div>
         <div style={{width:'100%',height:'100%',marginTop:"10px"}}>
           <Datagrid/>
         </div>
         <div style={{marginTop:"10px"}}>
                     
<Grid  container spacing={0}>
        <Grid justify={"flex-start"} style={{width:'100%',height:'100%'}} item xs={6}>
        <div style={{width:'100%',height:'100%'}}> {''} </div>
        </Grid>
        <Grid justify={"flex-start"} style={{width:'100%',height:'100%'}} item xs={6}>
        <div style={{width:'100%',height:'100%', display:"flex",justifyContent:'flex-end'}}> 
      
        <Button onClick={props.modalclose} style={{backgroundColor:"#FA5858",marginRight:'10px'}} variant="contained" color="secondary">
        Close
      </Button>
     

         </div>
        </Grid>
        </Grid>
           </div>
           
          </div>
         
        </Fade>
      </Modal>
    </div>
  );
}