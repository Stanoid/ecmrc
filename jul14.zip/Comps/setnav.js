import React from 'react';
import Settings from './settings/settings';
import Notif from './settings/notif';
import User from './settings/user';
import Support from './settings/support';


function Setnav(props) {
    const navtag = props.navtag;
 
switch(navtag){


    case 'set':
        return <Settings  closeaux={props.closeaux}/>;
    break;

    case 'def':
        return <div></div>;
    break;

    case 'user':
        return <User closeaux={props.closeaux} />;
    break;
    
    case 'not':
        return <Notif closeaux={props.closeaux} />;
    break;

    case 'sup':
        return <Support closeaux={props.closeaux} />;
    break;


}

 
}

export default Setnav