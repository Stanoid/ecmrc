import {useState} from 'react';
import {FaTimes} from  'react-icons/fa'
const Comp = (props) => {

    
    return (
        <> 

        
    
          <div>
          <button > <FaTimes/> </button>
         

          </div>
          
      
    </>
    )
}

export default Comp
