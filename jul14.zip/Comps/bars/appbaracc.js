import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Accconfig from '../../Screens/accounting/accconfig';
import Accentry from '../../Screens/accounting/accentry';
import Accexpence from '../../Screens/accounting/accexpence';
import Accinvoice from '../../Screens/accounting/Accinvoice';
import Accorders from '../../Screens/accounting/accorders';
import Accreports from '../../Screens/accounting/accreports';
import Box from '@material-ui/core/Box';
const useStyles = makeStyles((theme) => ({
  root: {
  
  display:'flex',
  backgroundColor:'white',
  justifyContent:"space-between",
  flexDirection:'row',
  alignItems:'center',
  height:"50px",
  zIndex:10,
  position:'fixed',
  width: `calc(100% - ${theme.spacing(9)}px)`,

   
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  indicator:{
    backgroundColor:'#68CAE1',
  },
  textColorSecondary:{
color:'#68CAE1'
  }
  
}));



function TabPanelo(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box style={{padding:'0px'}} p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}


export default function Appbaracc(props) {
  const classes = useStyles();

  const [value, setValue] = React.useState(0);


  const handleChange = (event, newValue) => {
    setValue(newValue);
  };


  function a11yProps(index) {
    return {
      id: `scrollable-auto-tab-${index}`,
      'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
  }

  return (
    <div   >
      <AppBar elevation={0} classes={{ root: classes.root }}  position="relative">
        <Toolbar  style={{width:'100%'}} variant="dense">
          <div style={{width:'100%', display:"flex",flexDirection:"row",alignItems:'center',justifyContent:'space-between'}}>
        
          <div  style={{fontSize:"18px",color:'grey'}} className={classes.title}>
            {props.pagetitle}
          </div>


    <div>
     {/* // <TabPanel/> */}
     <Tabs

classes={{
 
  indicator: classes.indicator,
}}
          value={value}
          onChange={handleChange}
          indicatorColor="primary"
          textColor="primary"
          variant="scrollable"
          scrollButtons="auto"
          aria-label="scrollable auto tabs example"
        >
          <Tab textColor="secondary" classes={{ textColorInherit: classes.textColorSecondary}} label="Configurarions" {...a11yProps(0)} />
          <Tab textColor="secondary" classes={{ textColorInherit: classes.textColorSecondary}} label="Orders" {...a11yProps(1)} />
          <Tab textColor="secondary" classes={{ textColorInherit: classes.textColorSecondary}} label="invoices" {...a11yProps(2)} />
          <Tab textColor="secondary" classes={{ textColorInherit: classes.textColorSecondary}} label="Create entry" {...a11yProps(3)} />
          <Tab textColor="secondary" classes={{ textColorInherit: classes.textColorSecondary}} label="Create expence" {...a11yProps(4)} />
          <Tab textColor="secondary" classes={{ textColorInherit: classes.textColorSecondary}} label="Reports" {...a11yProps(5)} />
      
        </Tabs>
    </div>

          <div style={{display:'flex',flexDirection:'row',alignItems:'center'}}  className={classes.title}>
         
          </div>
          </div>
          
        
        </Toolbar>
      </AppBar>
      <TabPanelo style={{width:"100%"}} value={value} index={0}>
      <Accconfig/>
      </TabPanelo>
      <TabPanelo style={{width:"100%"}} value={value} index={1}>
      <Accorders/>
      </TabPanelo>

      <TabPanelo style={{width:"100%"}} value={value} index={2}>
      <Accinvoice/>
      </TabPanelo>

      <TabPanelo style={{width:"100%"}} value={value} index={3}>
      <Accentry/>
      </TabPanelo>

      <TabPanelo style={{width:"100%"}} value={value} index={4}>
      <Accexpence/>
      </TabPanelo>


      <TabPanelo style={{width:"100%"}} value={value} index={5}>
      <Accreports/>
      </TabPanelo>
   
    
 
    
     

    </div>
  );
}