import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
const useStyles = makeStyles((theme) => ({
  root: {
  
  display:'flex',
  backgroundColor:'white',
  justifyContent:"space-between",
  flexDirection:'row',
  alignItems:'center',
  height:"50px",
  zIndex:-100,
  width: `calc(100% - ${theme.spacing(9)}px)`,

   
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  indicator:{
    backgroundColor:'#68CAE1',
  },
  textColorSecondary:{
color:'#68CAE1'
  }
  
}));



function TabPanelo(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanelo"
      hidden={value !== index}
      id={`scrollable-auto-tabpanelo-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}


export default function Appmin(props) {
  const classes = useStyles();

  const [value, setValue] = React.useState(0);


  const handleChange = (event, newValue) => {
    setValue(newValue);
  };


  function a11yProps(index) {
    return {
      id: `scrollable-auto-tab-${index}`,
      'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
  }

  return (
    <div   >
      <AppBar elevation={0} classes={{ root: classes.root }}  position="static">
        <Toolbar  style={{width:'100%'}} variant="dense">
          <div style={{width:'100%', display:"flex",flexDirection:"row",alignItems:'center',justifyContent:'space-between'}}>
        
          <div  style={{fontSize:"18px",color:'grey'}} className={classes.title}>
            {props.pagetitle}
          </div>


   

          <div style={{display:'flex',flexDirection:'row',alignItems:'center'}}  className={classes.title}>
          
          
          
          </div>
          </div>
          
        
        </Toolbar>
      </AppBar>
    
 

    </div>
  );
}