import { ThemeProvider } from '@material-ui/core';
import React from 'react';
import Nav from './nav' 
class Content extends React.Component {
 
  render() {
 
   // alert(this.props.navtag);
 

    return (
     <div onClick={this.props.clsaux} style={{width:'100%'}}>
 
<Nav  logout={this.props.logout} navtag={this.props.navtag}/>

     </div>

    );
  }
}
 

export default Content;